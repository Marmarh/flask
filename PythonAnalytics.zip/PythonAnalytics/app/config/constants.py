# app/config/constants.py

CREDENTIALS_PATH = "/app/data/key.json"
PROPERTY_ID = "336880320"
