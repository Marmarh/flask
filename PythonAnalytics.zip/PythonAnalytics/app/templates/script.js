const searchInput = document.getElementById('searchInput');
const searchResults = document.getElementById('searchResults');

searchInput.addEventListener('input', function() {
    const query = this.value.trim();

    if (query !== '') {
        fetch(`http://localhost:8000/api/company?query=${query}`)
            .then(response => response.json())
            .then(data => {
                displayResults(data);
            })
            .catch(error => {
                console.error('Error fetching data:', error);
            });
    } else {
        searchResults.innerHTML = '';
    }
});

function displayResults(results) {
    searchResults.innerHTML = '';
    results.forEach(company => {
        const li = document.createElement('li');
        li.textContent = company.name;
        searchResults.appendChild(li);
    });
}
