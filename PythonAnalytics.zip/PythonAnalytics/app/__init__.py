# app/__init__.py

from flask import Flask

# Initialiser l'application Flask
app = Flask(__name__)

from app import routes
