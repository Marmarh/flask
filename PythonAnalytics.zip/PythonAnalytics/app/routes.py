from flask import render_template, request, redirect, session, jsonify
import requests
from app import app
from flaskext.mysql import MySQL
from app.helpers import (
    hash_password,  
    check_password,
    get_total_visitors,
    get_total_page_views,
    get_average_session_duration,
    get_average_session_duration_path,
    get_list_events,
    get_total_page_views_by_path,
    get_total_page_views_by_paths,
    extract_activity_slugs_from_url,
    get_calculate_total_views,
    get_company_data,
    
)

app.secret_key = "MarmarAnalytics2024+"


@app.route("/home", methods=["POST", "GET"])
def display_report():
    if request.method == "POST":   
        slug = request.form["searchInput"]
        

        query = slug
        
        
        # Code pour récupérer les données de l'API Symfony

        validationYear2022 = '2022'  # Assurez-vous que le formulaire contient l'année de validation
        validationYear2023 = '2023'
        validationYear2024 = '2024'
        typeMessage = 1  # Assurez-vous que le formulaire contient le type de message
        validation = 1  # Assurez-vous que le formulaire contient la validation
        url_symfony2022 = f"http://46.101.34.87/api/devis/{slug}/{validationYear2022}/{typeMessage}/{validation}"
        url_symfony2023 = f"http://46.101.34.87/api/devis/{slug}/{validationYear2023}/{typeMessage}/{validation}"
        url_symfony2024 = f"http://46.101.34.87/api/devis/{slug}/{validationYear2024}/{typeMessage}/{validation}"
        response_symfony2022 = requests.get(url_symfony2022)
        response_symfony2023 = requests.get(url_symfony2023)
        response_symfony2024 = requests.get(url_symfony2024)
        
        # Vérifier le statut de la réponse Symfony
        if response_symfony2022.status_code == 200:
            devis_counts2022 = response_symfony2022.json()
        if response_symfony2023.status_code == 200:
            devis_counts2023 = response_symfony2023.json()
        if response_symfony2024.status_code == 200:
            devis_counts2024 = response_symfony2024.json()
        else:
            return render_template("error.html", error_message="Failed to retrieve data from Symfony API")

        # Code pour récupérer les autres données de l'application Flask
        event_name = f"Telephone "+(slug.lower())
        date_start = request.form["start_date"]
        date_end = request.form["end_date"]
        url = "http://46.101.34.87/api/activities/"+slug
        page_path = "/fr/annuaire-entreprise/"+slug
        page_paths = extract_activity_slugs_from_url(url)
        
        if page_paths is not None:  # Ajoutez cette vérification
            total_visitors = get_total_visitors(date_start, date_end)
            total_page_views_by_paths = get_total_page_views_by_paths(date_start, date_end, page_paths)
            total_page_views = get_total_page_views(date_start, date_end)
            average_session_duration = get_average_session_duration(date_start, date_end)
            average_session_duration_path = get_average_session_duration_path(date_start, date_end,page_path)
            list_events = get_list_events(date_start, date_end, event_name)
            activity_slugs = extract_activity_slugs_from_url(url)
            total_page_views_by_path = get_total_page_views_by_path(date_start, date_end,page_path)
            total_views = get_calculate_total_views(date_start, date_end, page_paths)
            data = get_company_data(query)
            
            return render_template(
                "report.html",
                devis_counts2022=devis_counts2022,
                devis_counts2023=devis_counts2023,
                devis_counts2024=devis_counts2024,
                total_visitors=total_visitors,
                total_page_views=total_page_views,
                average_session_duration=average_session_duration,
                average_session_duration_path=average_session_duration_path,
                list_events=list_events,
                total_page_views_by_paths=total_page_views_by_paths,
                activity_slugs=activity_slugs,
                page_paths=page_paths,
                total_page_views_by_path=total_page_views_by_path,
                total_views=total_views,
                date_s=date_start,
                date_e=date_end,
                slug=slug,
                data=data,
            )
        else:
            # Gérez le cas où page_paths est None, peut-être avec un message d'erreur approprié
            return render_template("error.html",
                                   error_message="Page paths not found",
                                   slug=slug,

                                   
                                   )
    
    # Si la méthode est GET, vous pouvez simplement renvoyer le template avec le formulaire
    return render_template("home.html")
@app.route("/")
def display_home():
    return render_template("index.html")

# Configuration MySQL
"""app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'admindbkerix'
app.config['MYSQL_PASSWORD'] = 'keriX2021X'
app.config['MYSQL_DB'] = 'db_analatics'"""

# Initialisation de MySQL
#mysql = MySQL(app)

"""@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = hash_password(request.form['password'])
        conn = mysql.connect()  # Utilise mysql.connect() pour obtenir une connexion
        cursor = conn.cursor()
        cursor.execute('USE db_analatics')
        cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, password))
        conn.commit()
        cursor.close()
        conn.close()
        return redirect('/login')
    return render_template('register.html')"""

#@app.route('/login', methods=['GET', 'POST'])
#def login():
    #if request.method == 'POST':
        #username = request.form['username']
        #password = request.form['password']
        #conn = mysql.connect()  # Utilise mysql.connect() pour obtenir une connexion
        #cursor = conn.cursor()
        #cursor.execute('USE db_analatics')
        #cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        #user = cursor.fetchone()
        #cursor.close()
        #conn.close()
        #if user and check_password(user[2], password):  # Assurez-vous que le mot de passe est à l'index 2
            #session['username'] = username
            #return redirect('/')
        #else:
            #return "Invalid username or password"
    #return render_template('login.html')
# List of test credentials
TEST_USERS = [
    {'username': 'admin', 'password': 'admin'},
    {'username': 'simon', 'password': 'simon'},
    {'username': 'testuser3', 'password': 'testpassword3'},
    # Add more users as needed
]

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Check if the provided credentials match any of the hardcoded ones
        user = next((user for user in TEST_USERS if user['username'] == username and user['password'] == password), None)
        
        if user:
            session['username'] = username
            return redirect('/')
        else:
            return render_template('login.html')
    
    

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect('/login')

@app.route('/search_company')
def search_company():
    query = request.args.get('query')
    api_url = 'http://46.101.34.87/api/company'
    params = {'query': query}

    try:
        response = requests.get(api_url, params=params)
        data = response.json()
        return jsonify(data)
    except Exception as e:
        return jsonify({'error': str(e)})
    

    
    
