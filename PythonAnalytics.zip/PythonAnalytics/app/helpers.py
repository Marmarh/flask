# app/helpers.py

import os,requests
from datetime import datetime, timedelta
from langdetect import detect
from google.oauth2 import service_account
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from flask_bcrypt import Bcrypt
from google.analytics.data_v1beta.types import (
    DateRange,
    Metric,
    Dimension,
    RunReportRequest,
    FilterExpression,
    Filter,
)

bcrypt = Bcrypt()

def hash_password(password):
    # Hacher le mot de passe et le décoder en UTF-8
    return bcrypt.generate_password_hash(password).decode('utf-8')

def check_password(hashed_password, password):
    # Vérifier si le mot de passe correspond au hachage
    return bcrypt.check_password_hash(hashed_password, password)


from app.config.constants import CREDENTIALS_PATH, PROPERTY_ID

# Créer un client Google Analytics Data en utilisant les informations d'identification du fichier JSON
# Obtenez le chemin absolu vers le répertoire actuel
current_directory = os.path.dirname(__file__)

# Construisez le chemin vers le fichier key.json
credentials_path = os.path.join(current_directory, "data", "key.json")


client = BetaAnalyticsDataClient.from_service_account_json(credentials_path)


def get_total_visitors(start_date, end_date):
    #  end_date = datetime.now().strftime("%Y-%m-%d")
    #  start_date = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")
    request = RunReportRequest(
        property=f"properties/{PROPERTY_ID}",
       # dimensions=[Dimension(name="dateHourMinute")],
        metrics=[Metric(name="totalUsers")],
        date_ranges=[DateRange(start_date=start_date, end_date=end_date)],
    )
    response = client.run_report(request)
    total_visitors = sum([int(row.metric_values[0].value) for row in response.rows])
    return total_visitors


def get_average_session_duration(start_date, end_date):

    # Définir les dates pour les 7 derniers jours
    #  end_date = datetime.now().strftime("%Y-%m-%d")
    #  start_date = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")

    # Définir la métrique pour la durée moyenne de session
    metrics = [
        Metric(name="averageSessionDuration"),
    ]

    # Définir la requête
    request = RunReportRequest(
        property=f"properties/{PROPERTY_ID}",
        metrics=metrics,
        date_ranges=[DateRange(start_date=start_date, end_date=end_date)],
    )

    # Exécuter la requête
    response = client.run_report(request)

    # Extraire la durée moyenne de session en secondes
    average_session_duration_seconds = float(response.rows[0].metric_values[0].value)

    # Formater la durée moyenne de session en heure:minute:seconde
    minutes, seconds = divmod(average_session_duration_seconds, 60)
    hours, minutes = divmod(minutes, 60)
    average_session_duration = "{:02}:{:02}:{:02}".format(
        int(hours), int(minutes), int(seconds)
    )

    return average_session_duration


def get_average_session_duration_path(start_date, end_date, page_path=None):
    # Définir les dates pour la plage de dates
    # end_date = datetime.now().strftime("%Y-%m-%d")
    # start_date = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")

    # Définir la métrique pour la durée moyenne de session
    metrics = [Metric(name="averageSessionDuration")]

    # Définir les dimensions (ajouter le chemin de page si fourni)
    dimensions = []
    if page_path:
        dimensions.append(Dimension(name="pagePath"))

    # Définir la requête
    request = RunReportRequest(
        property=f"properties/{PROPERTY_ID}",
        metrics=metrics,
        dimensions=dimensions,
        date_ranges=[DateRange(start_date=start_date, end_date=end_date)],
        dimension_filter={"filter": {"field_name": "pagePath", "string_filter": {"match_type": "EXACT", "value": page_path}}} if page_path else None
    )

    # Exécuter la requête
    response = client.run_report(request)

    # Extraire la durée moyenne de session en secondes
    average_session_duration_seconds = float(response.rows[0].metric_values[0].value)

    # Formater la durée moyenne de session en heure:minute:seconde
    minutes, seconds = divmod(average_session_duration_seconds, 60)
    hours, minutes = divmod(minutes, 60)
    average_session_duration_path = "{:02}:{:02}:{:02}".format(
        int(hours), int(minutes), int(seconds)
    )

    return average_session_duration_path


def get_total_page_views(start_date, end_date):

    # Définir les dates pour les 7 derniers jours
    #  end_date = datetime.now().strftime("%Y-%m-%d")
    #  start_date = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")

    # Définir la métrique pour le nombre total de vues d'écran (pages vues)
    metrics = [
        Metric(name="screenPageViews"),
    ]

    # Définir la requête
    request = RunReportRequest(
        property=f"properties/{PROPERTY_ID}",
        metrics=metrics,
        date_ranges=[DateRange(start_date=start_date, end_date=end_date)],
    )

    # Exécuter la requête
    response = client.run_report(request)

    # Extraire le nombre total de vues d'écran
    total_page_views = int(response.rows[0].metric_values[0].value)

    return total_page_views


# Définir la fonction avec les paramètres
def get_list_events(start_date, end_date, event_name):

   
    # Définir la dimension pour l'événement (label)
    dimension = Dimension(name="customEvent:event_label")

    # Définir la métrique pour le nombre de clics
    metric = Metric(name="eventCount")

    # Définir la requête
    request = RunReportRequest(
        property=f"properties/{PROPERTY_ID}",
        dimensions=[dimension],
        metrics=[metric],
        date_ranges=[DateRange(start_date=start_date, end_date=end_date)],
    )

    # Exécuter la requête
    response = client.run_report(request)

    # Extraire les noms des événements et le nombre de clics associés
    list_events = [
       # (row.dimension_values[0].value, row.metric_values[0].value)
        (row.metric_values[0].value)
        for row in response.rows
        if event_name == row.dimension_values[0].value
    ]

    return list_events


def get_total_page_views_by_path(start_date, end_date, page_path):
    request = RunReportRequest(
        property=f"properties/{PROPERTY_ID}",
        dimensions=[Dimension(name="pagePathPlusQueryString")],
        metrics=[Metric(name="screenPageViews")],
        date_ranges=[DateRange(start_date=start_date, end_date=end_date)],
        dimension_filter=FilterExpression(
            filter=Filter(
                field_name="pagePathPlusQueryString",
                string_filter=Filter.StringFilter(
                    value=page_path, match_type="EXACT"
                ),
            )
        ),
    )

    # Get the response
    response = client.run_report(request)

    # Get total page views and page URL
    total_page_views_by_path = 0
    page_url = ""
    if response.row_count > 0:
        total_page_views_by_path = response.rows[0].metric_values[0].value
        page_url = response.rows[0].dimension_values[0].value

    return total_page_views_by_path
    # return total_page_views_by_path, page_url




def get_total_page_views_by_paths(start_date, end_date, page_paths):
    if not page_paths:
        return {"error": "La liste des chemins de pages est vide."}

    dimensions = [Dimension(name="pagePath"), Dimension(name="pageTitle")]
    metrics = [Metric(name="screenPageViews")]
    date_range = DateRange(start_date=start_date, end_date=end_date)

    total_page_views_by_paths = {}

    request = {
        "property": f"properties/{PROPERTY_ID}",
        "date_ranges": [date_range],
        "dimensions": dimensions,
        "metrics": metrics,
        "dimension_filter": {
            "or_group": {
                "expressions": [
                    FilterExpression(
                        filter=Filter(
                            field_name="pagePath",
                            string_filter=Filter.StringFilter(
                                value=page_path, match_type="EXACT"
                            ),
                        )
                    )
                    for page_path in page_paths
                ]
            }
        },
    }

    response = client.run_report(request=request)

    for row in response.rows:
        page_path = row.dimension_values[0].value
        page_title = row.dimension_values[1].value
        if detect(page_title) == 'fr':
            short_title = page_title.split('Maroc |')[0].strip()
            activity_slug = page_path.split('/fr/annuaire-entreprise/')[1]
            total_page_views = row.metric_values[0].value
            total_page_views_by_paths[activity_slug] = {
                "page_views": total_page_views,
                "page_title": short_title
            }

    return total_page_views_by_paths


def extract_activity_slugs_from_url(url):
    try:
        response = requests.get(url)
        if response.status_code == 200:
            json_data = response.json()
            formatted_activity_slugs = []
            
            for item in json_data:
                if 'activitySlug' in item:
                    activity_slug = item['activitySlug']
                    formatted_activity_slugs.append(f"/fr/annuaire-entreprise/{activity_slug}.html".replace("'", '"'))
                
                if 'slug' in item:
                    slug = item['slug']
                    formatted_activity_slugs.append(f"/fr/annuaire-entreprise/{slug}.html".replace("'", '"'))
            
            return formatted_activity_slugs
        else:
            print("La requête à l'API a échoué avec le code de statut :", response.status_code)
            return None
    except requests.exceptions.RequestException as e:
        print("Une erreur s'est produite lors de la requête à l'API :", e)
        return None








def get_calculate_total_views(start_date, end_date, page_paths):
    if not page_paths:
        return 0

    dimensions = [Dimension(name="pagePath"), Dimension(name="pageTitle")]
    metrics = [Metric(name="screenPageViews")]
    date_range = DateRange(start_date=start_date, end_date=end_date)

    total_views = 0

    request = {
        "property": f"properties/{PROPERTY_ID}",
        "date_ranges": [date_range],
        "dimensions": dimensions,
        "metrics": metrics,
        "dimension_filter": {
            "or_group": {
                "expressions": [
                    FilterExpression(
                        filter=Filter(
                            field_name="pagePath",
                            string_filter=Filter.StringFilter(
                                value=page_path, match_type="EXACT"
                            ),
                        )
                    )
                    for page_path in page_paths
                ]
            }
        },
    }

    response = client.run_report(request=request)

    for row in response.rows:
        page_path = row.dimension_values[0].value
        page_title = row.dimension_values[1].value
        if detect(page_title) == 'fr':
            short_title = page_title.split('Maroc |')[0].strip()
            activity_slug = page_path.split('/fr/annuaire-entreprise/')[1]
            page_views = int(row.metric_values[0].value)
            total_views += page_views
            
            print(f"Page Path: {page_path}, Short Title: {short_title}, Page Views: {page_views}")

    return total_views


def get_company_data(query):
    api_url = 'http://46.101.34.87/api/company/name'
    params = {'query': query}
    
    try:
        response = requests.get(api_url, params=params)
        response.raise_for_status()  # Raises an HTTPError if the HTTP request returned an unsuccessful status code
        data = response.json()
        
        # Extracting company names and joining them into a single string
        company_names = ', '.join(item['companyName'] for item in data if 'companyName' in item)
        return company_names
    
    except requests.exceptions.RequestException as e:
        return {'error': str(e)}